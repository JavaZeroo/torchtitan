"""Render exact Perfetto event intervals; no synthesized GPU activity."""

import argparse
import csv
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np


COLORS = {
    "GEMM": "#2676aa", "NCCL": "#d7a435",
    "Copy": "#7e8e9a", "Pointwise/other": "#6d956a",
}


def render(data, output):
    measurements = json.loads((data / "measurements.json").read_text())
    summaries = json.loads((data / "trace_summary.json").read_text())
    annotations = json.loads((data / "compute_annotations.json").read_text())
    with (data / "events.csv").open() as f:
        events = list(csv.DictReader(f))
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11,
                         "text.color": "#24333b", "axes.labelcolor": "#24333b",
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.edgecolor": "#b1bcc4", "xtick.color": "#52636e",
                         "ytick.color": "#52636e"})
    for workload, name, limit, bar_limit in (
        ("k25_slice", "Kimi K2.5 slice | 3 layers, 16 experts", 260, 230),
        ("moonlight_slice", "Moonlight slice | 5 layers, 64 experts", 110, 65),
    ):
        fig = plt.figure(figsize=(15, 9.2), facecolor="white")
        grid = fig.add_gridspec(2, 2, height_ratios=[2.8, 1], hspace=.40, wspace=.18)
        fig.suptitle(f"DistMuon placement: {name}", x=.055, ha="left", y=.975,
                     fontsize=19, fontweight="bold")
        fig.text(.055, .932, "8 x A100 SXM4 40 GB  |  EP8 / FSDP8  |  One warmed profiled optimizer step; events queried with Perfetto", fontsize=11)
        fig.legend(handles=[Patch(color=c, label=n) for n, c in COLORS.items()],
                   loc="upper left", bbox_to_anchor=(.05, .914), ncol=4,
                   frameon=False, fontsize=11, handlelength=1.2, columnspacing=2)
        for column, variant in enumerate(("base", "pr")):
            ax = fig.add_subplot(grid[0, column])
            subset = [r for r in events if r["workload"] == workload and r["variant"] == variant]
            streams = sorted({int(r["stream"]) for r in subset})
            assert len(streams) == 2, streams
            for rank in range(8):
                row = next(s for s in summaries if s["workload"] == workload
                           and s["variant"] == variant and s["rank"] == rank)
                for lane, stream in enumerate(streams):
                    for family, color in COLORS.items():
                        spans = [(int(r["relative_ns"]) / 1e6, int(r["duration_ns"]) / 1e6)
                                 for r in subset if int(r["rank"]) == rank
                                 and int(r["stream"]) == stream and r["family"] == family]
                        ax.broken_barh(spans, (rank + lane * .31, .27),
                                       facecolors=color, edgecolors="none", zorder=2)
                ax.plot([row["window_ms"]] * 2, [rank-.04, rank+.61],
                        color="#34454e", linewidth=1, zorder=3)
            for r in annotations:
                if r["workload"] != workload or r["variant"] != variant:
                    continue
                if workload != "k25_slice" or not r["fqn"].startswith("layers.0.feed_forward"):
                    continue
                label = "w13" if ".w13." in r["fqn"] else "w2"
                ax.text((r["relative_ns"] + r["duration_ns"] / 2) / 1e6,
                        r["rank"] - .09, label, ha="center", va="bottom",
                        fontsize=10, fontweight="bold", color="#24333b")
            tag = "main 8a3f5bcaa4" if variant == "base" else "PR 80a3bfbd92"
            ax.set_title(tag, loc="left", fontsize=14, fontweight="bold", pad=16)
            ax.set_xlim(0, limit)
            ax.set_ylim(7.8, -.55)
            ax.set_yticks(np.arange(8) + .27, [f"GPU {rank}" for rank in range(8)])
            ax.tick_params(axis="y", length=0)
            ax.set_xlabel("ms from each rank's own optimizer-window start")
            ax.grid(axis="x", color="#e8ecef", linewidth=.7, zorder=0)
            ax.spines["left"].set_visible(False)
            bottom = fig.add_subplot(grid[1, column])
            values = [next(s for s in summaries if s["workload"] == workload
                           and s["variant"] == variant and s["rank"] == rank)
                      ["families"]["GEMM"]["sum_ms"] for rank in range(8)]
            bars = bottom.bar(np.arange(8), values, width=.66,
                              color=COLORS["GEMM"], edgecolor="#16486a", linewidth=.5)
            bottom.bar_label(bars, labels=[f"{v:.1f}" for v in values], padding=3, fontsize=10)
            bottom.set_ylim(0, bar_limit)
            bottom.set_xticks(range(8), [f"r{r}" for r in range(8)])
            bottom.set_ylabel("GEMM ms (sum)")
            bottom.grid(axis="y", color="#e8ecef", linewidth=.7, zorder=0)
            bottom.set_axisbelow(True)
        m = measurements[workload]
        fig.text(.055, .087,
                 f"Unprofiled optimizer median: {m['base']['median_ms']:.2f} -> {m['pr']['median_ms']:.2f} ms "
                 f"({m['reduction_percent']:.1f}% lower).  3 trials x 12 timed steps; 4 warmup steps/trial.",
                 fontsize=12, fontweight="bold")
        fig.text(.055, .052, "Each GPU: upper lane = compute stream; lower lane = transfer stream. Vertical ticks mark CPU-window ends.", fontsize=10)
        fig.text(.055, .026, "Rank-local alignment, not a globally synchronized timeline. NCCL includes waiting; busy time is not SM utilization. Not full-training speedup.", fontsize=10)
        fig.subplots_adjust(left=.064, right=.98, top=.835, bottom=.17)
        fig.savefig(output / f"{workload}_trace.png", dpi=140)
        plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).parent / "analysis")
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "analysis")
    args = parser.parse_args()
    render(args.data, args.output)
