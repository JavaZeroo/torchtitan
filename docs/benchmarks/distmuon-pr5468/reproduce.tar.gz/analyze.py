"""Summarize unprofiled measurements and query captured traces with Perfetto."""

import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import statistics
import subprocess


PREPARE_SQL = """
INCLUDE PERFETTO MODULE intervals.overlap;
INCLUDE PERFETTO MODULE intervals.intersect;
CREATE OR REPLACE PERFETTO TABLE profile_window AS
SELECT s.id,s.ts,s.dur FROM slice AS s
WHERE s.category='user_annotation'
  AND s.name='DistMuon/optimizer_window' AND s.dur>0;
CREATE OR REPLACE PERFETTO TABLE cuda_events AS
SELECT s.id,s.ts,s.dur,s.track_id,s.category,s.name,
       EXTRACT_ARG(s.arg_set_id,'args.device') AS device,
       EXTRACT_ARG(s.arg_set_id,'args.stream') AS stream
FROM slice AS s
WHERE s.category IN ('kernel','gpu_memcpy','gpu_memset') AND s.dur>0;
CREATE OR REPLACE PERFETTO TABLE window_events AS
SELECT i.id_0 AS id,i.ts,i.dur,e.track_id,e.category,e.name,e.device,e.stream,
CASE WHEN e.category='kernel' AND regexp('nccl',e.name,'i') THEN 'NCCL'
     WHEN e.category='kernel' AND regexp('gemm|bmm',e.name,'i') THEN 'GEMM'
     WHEN e.category IN ('gpu_memcpy','gpu_memset') THEN 'Copy'
     ELSE 'Pointwise/other' END AS family
FROM _interval_intersect!((cuda_events,profile_window),()) AS i
JOIN cuda_events AS e ON e.id=i.id_0;
CREATE OR REPLACE PERFETTO TABLE busy_intervals AS
SELECT ROW_NUMBER() OVER (ORDER BY b.ts) AS id,b.ts,b.dur
FROM interval_merge_overlapping!((
  SELECT e.ts,e.dur FROM window_events AS e
),0) AS b;
"""

EVENT_SQL = """
SELECT e.id,e.ts-w.ts AS relative_ns,e.dur AS duration_ns,
       e.device,e.stream,e.family,e.name
FROM window_events AS e CROSS JOIN profile_window AS w ORDER BY e.ts;
"""

SUMMARY_SQL = """
SELECT w.dur/1e6 AS window_ms,
       (SELECT SUM(b.dur)/1e6 FROM busy_intervals AS b) AS busy_union_ms,
       (SELECT COUNT(*) FROM window_events AS e) AS num_events,
       (SELECT COUNT(DISTINCT e.id) FROM window_events AS e) AS unique_events
FROM profile_window AS w;
"""

FAMILY_SQL = """
SELECT e.family,COUNT(*) AS num_events,SUM(e.dur)/1e6 AS sum_ms
FROM window_events AS e GROUP BY e.family;
"""

ANNOTATION_SQL = """
SELECT s.ts-w.ts AS relative_ns,s.dur AS duration_ns,s.name,s.track_id
FROM slice AS s CROSS JOIN profile_window AS w
WHERE s.category='gpu_user_annotation'
  AND s.name GLOB 'DistMuon/compute/*' AND s.dur>0 ORDER BY s.ts;
"""


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def query(tp, session, sql):
    result = subprocess.run(
        [str(tp), "query", "--remote", session, sql],
        text=True, capture_output=True, check=True,
    )
    return list(csv.DictReader(io.StringIO(result.stdout)))


def traces(root, output, tp):
    summaries, events, annotations, manifest = [], [], [], []
    paths = sorted(root.glob("*/*/trial1/trace_rank*.json.gz"))
    assert len(paths) == 32
    for index, trace in enumerate(paths):
        workload, variant, _, filename = trace.relative_to(root).parts
        rank = int(filename.split("rank")[1].split(".")[0])
        identity = dict(workload=workload, variant=variant, rank=rank)
        session = f"pr5468_{workload}_{variant}_{rank}"
        subprocess.run(
            [str(tp), "server", "unix", "--name", session,
             "--daemonize", str(trace)], check=True, capture_output=True,
        )
        try:
            for table in ("slice", "args"):
                query(tp, session, f"SELECT * FROM {table} LIMIT 0;")
            query(tp, session, PREPARE_SQL)
            for table in ("profile_window", "cuda_events", "window_events", "busy_intervals"):
                query(tp, session, f"SELECT * FROM {table} LIMIT 0;")
            rows = query(tp, session, SUMMARY_SQL)
            assert len(rows) == 1, (trace, rows)
            record = {**identity, **{k: float(v) for k, v in rows[0].items()}}
            assert record["num_events"] == record["unique_events"]
            record["families"] = {
                r["family"]: {"num_events": int(r["num_events"]), "sum_ms": float(r["sum_ms"])}
                for r in query(tp, session, FAMILY_SQL)
            }
            summaries.append(record)
            rows = query(tp, session, EVENT_SQL)
            assert {int(r["device"]) for r in rows} == {rank}
            for r in rows:
                events.append({**identity, "stream": int(r["stream"]),
                               "relative_ns": int(r["relative_ns"]),
                               "duration_ns": int(r["duration_ns"]),
                               "family": r["family"], "name": r["name"]})
            for r in query(tp, session, ANNOTATION_SQL):
                annotations.append({**identity, "relative_ns": int(r["relative_ns"]),
                                    "duration_ns": int(r["duration_ns"]),
                                    "fqn": r["name"].removeprefix("DistMuon/compute/")})
            manifest.append({"path": str(trace.relative_to(root)),
                             "sha256": hashlib.sha256(trace.read_bytes()).hexdigest()})
            print(f"{index + 1}/32 {workload} {variant} rank{rank}: "
                  f"window {record['window_ms']:.2f} ms", flush=True)
        finally:
            subprocess.run([str(tp), "server", "kill", session], capture_output=True)
    dump(output / "trace_summary.json", summaries)
    dump(output / "compute_annotations.json", annotations)
    dump(output / "trace_manifest.json", manifest)
    with (output / "events.csv").open("w") as f:
        writer = csv.DictWriter(f, fieldnames=list(events[0]))
        writer.writeheader()
        writer.writerows(events)


def measurements(root, output):
    result = {}
    checks = 0
    for workload in ("k25_slice", "moonlight_slice"):
        result[workload] = {}
        runs = {}
        for variant in ("base", "pr"):
            trials = []
            for trial in range(1, 4):
                ranks = [json.loads((root / workload / variant / f"trial{trial}" /
                                    f"rank{rank}.json").read_text()) for rank in range(8)]
                runs[variant, trial] = ranks
                assert all(len(r["steps"]) == 16 for r in ranks)
                assert all(r["summary"]["num_timed_steps"] == 12 for r in ranks)
                values = [max(r["steps"][step]["total_ms"] for r in ranks)
                          for step in range(4, 16)]
                flops = [r["ns_flops"] for r in ranks]
                trials.append({
                    "trial": trial, "critical_step_ms": values,
                    "critical_median_ms": statistics.median(values),
                    "peak_allocated_gib": max(r["summary"]["peak_bytes_max"] for r in ranks) / 2**30,
                    "ns_flops_by_rank": flops,
                    "ns_flops_max_over_mean": max(flops) / statistics.mean(flops),
                    "remote_send_bytes_by_rank": [r["remote_send_bytes"] for r in ranks],
                    "remote_send_mib_sum": sum(r["remote_send_bytes"] for r in ranks) / 2**20,
                })
            medians = [t["critical_median_ms"] for t in trials]
            result[workload][variant] = {
                "median_ms": statistics.median(medians),
                "trial_range_ms": [min(medians), max(medians)], "trials": trials,
            }
        for trial in range(1, 4):
            for b, p in zip(runs["base", trial], runs["pr", trial]):
                assert b["digests"] == p["digests"]
                checks += 2 * len(b["digests"])
        result[workload]["reduction_percent"] = 100 * (
            1 - result[workload]["pr"]["median_ms"] / result[workload]["base"]["median_ms"])
        assert sum(result[workload]["base"]["trials"][0]["ns_flops_by_rank"]) == sum(
            result[workload]["pr"]["trials"][0]["ns_flops_by_rank"])
    numerics = {"optimizer_digest_comparisons": checks}
    training_checks = 0
    for rank in range(8):
        pair = [json.loads((root / "debug_text" / variant / "trial1" /
                           f"rank{rank}.json").read_text()) for variant in ("base", "pr")]
        assert len(pair[0]["step_digests"]) == 40
        assert pair[0]["step_digests"] == pair[1]["step_digests"]
        training_checks += sum(2 * len(d) for d in pair[0]["step_digests"])
    from harness.tb_metrics import read
    base = read(root / "debug_text/base/trial1/dump/tb")
    pr = read(root / "debug_text/pr/trial1/dump/tb")
    assert base == pr and set(base) == {"loss", "grad_norm"}
    assert len(base["loss"]) == len(base["grad_norm"]) == 40
    numerics.update(training_digest_comparisons=training_checks,
                    training_steps=40, metrics_bitwise_equal=True, metrics=base)
    result["numerics"] = numerics
    dump(output / "measurements.json", result)
    print(json.dumps({w: {v: result[w][v]["median_ms"] for v in ("base", "pr")}
                      for w in ("k25_slice", "moonlight_slice")}, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).parent / "results")
    parser.add_argument("--output", type=Path, default=Path(__file__).parent / "analysis")
    parser.add_argument("--skip-traces", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(exist_ok=True)
    measurements(args.root, args.output)
    if not args.skip_traces:
        traces(args.root, args.output, Path(os.environ["SKILL_ROOT"]) / "bin/trace_processor")


if __name__ == "__main__":
    main()
