#!/usr/bin/env bash
set -euo pipefail
PROFILE_ROOT=/workspace/pr5468
mkdir -p "$PROFILE_ROOT/base" "$PROFILE_ROOT/pr" "$PROFILE_ROOT/results"
tar -xzf "$PROFILE_ROOT/base.tar.gz" -C "$PROFILE_ROOT/base"
tar -xzf "$PROFILE_ROOT/pr.tar.gz" -C "$PROFILE_ROOT/pr"
python -m pip install -q uv
uv venv --python 3.12 "$PROFILE_ROOT/venv"
uv pip install --python "$PROFILE_ROOT/venv/bin/python" \
  'torch==2.16.0.dev20261016+cu130' 'torchvision==0.30.0.dev20261016+cu130' \
  --index-url https://download.pytorch.org/whl/nightly/cu130
uv pip install --python "$PROFILE_ROOT/venv/bin/python" \
  -r "$PROFILE_ROOT/pr/requirements.txt" pytest expecttest
USE_CPP=0 uv pip install --python "$PROFILE_ROOT/venv/bin/python" --pre torchao \
  --index-url https://download.pytorch.org/whl/nightly/cu130
uv pip freeze --python "$PROFILE_ROOT/venv/bin/python"
nvidia-smi --query-gpu=index,name,memory.total,driver_version --format=csv
nvidia-smi topo -m
echo SETUP_DONE
