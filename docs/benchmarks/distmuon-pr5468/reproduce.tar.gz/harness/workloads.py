"""Fixed production-shape slices and a text-only debug numerics workload."""

from dataclasses import replace
from unittest.mock import patch

from torchtitan.components.data import ConcatThenSplitPackingConfig, GrainDataLoader
from torchtitan.components.data.text_datasets import DATASETS
from torchtitan.components.loss import ChunkedLossWrapper, CrossEntropyLoss
from torchtitan.components.optim import LRSchedulersContainer, Optim
from torchtitan.config import TrainingConfig
from torchtitan.config.parallelism import ParallelismConfig
from torchtitan.distributed.activation_remat import FullActivationRematConfig
from torchtitan.models.kimi_k2_7 import flavors
from torchtitan.observability.metrics import MetricsProcessor
from torchtitan_recipes.tests.models import kimi_k2_7 as kimi


def _config(flavor, *, layers, experts, seq_len=512):
    parallelism = ParallelismConfig(
        data_parallel_shard_degree=8, expert_parallel_degree=8
    )
    original = flavors._build_kimi_layers

    def build_layers(**kwargs):
        kwargs.update(n_layers=layers, num_experts=experts)
        return original(**kwargs)

    with patch.object(flavors, "_build_kimi_layers", side_effect=build_layers):
        model = flavors.build_model_config(
            flavor, parallelism=parallelism, seq_len=seq_len
        )
    model.vision_encoder = None
    model.vocab_size = 4096
    model.tok_embeddings = replace(model.tok_embeddings, num_embeddings=4096)
    model.lm_head = replace(model.lm_head, out_features=4096)
    config = kimi._KimiTrainerConfig(
        model=model,
        hf_assets_path="./tests/assets/tokenizer",
        loss=ChunkedLossWrapper.Config(
            loss_fn=CrossEntropyLoss.Config(global_vocab_size=4096)
        ),
        dataloader=GrainDataLoader.Config(
            dataset=ConcatThenSplitPackingConfig(dataset=DATASETS["c4_test"])
        ),
        optim=Optim.Config(
            optimizer=kimi._dist_muon_optimizer(
                model, muon_lr=3e-4, adamw_lr=3e-4, parallelism=parallelism
            ),
            lr_scheduler=LRSchedulersContainer.Config(
                warmup_steps=2, decay_ratio=0.8, decay_type="linear",
                min_lr_factor=0.0,
            ),
        ),
        training=TrainingConfig(
            num_tokens_per_microbatch_per_dp_rank=seq_len,
            max_context_length=seq_len, steps=40, disable_cuda_graphs=True,
        ),
        parallelism=parallelism,
        checkpointer=None,
        activation_remat=FullActivationRematConfig(),
        metrics=MetricsProcessor.Config(log_freq=1),
    )
    config.debug.seed = 42
    config.debug.deterministic = True
    config.debug.deterministic_warn_only = False
    return config


def k25_slice():
    return _config("Kimi-K2.5", layers=3, experts=16)


def moonlight_slice():
    return _config("moonlight-16B-A3B", layers=5, experts=64)


def debug_text():
    return _config("debugmodel", layers=6, experts=8, seq_len=256)
