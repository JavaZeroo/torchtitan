#!/usr/bin/env bash
set -euo pipefail
PROFILE_ROOT=/workspace/pr5468
PROFILE_BASE=8a3f5bcaa4fd51ea6af6fb4bbb90ef03bcb139d0
PROFILE_HEAD=80a3bfbd92f7b523551edd34a168f5cc8d2ca710
export OMP_NUM_THREADS=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTORCH_ALLOC_CONF=expandable_segments:True
export MB_SEED=42 MB_DETERMINISTIC=1 MB_TIMEOUT=180
export TORCHINDUCTOR_CACHE_DIR="$PROFILE_ROOT/inductor_cache"

run_one() {
  local variant=$1 workload=$2 trial=$3 mode=$4
  local output="$PROFILE_ROOT/results/$workload/$variant/trial$trial"
  local steps=16 profile_step=0
  mkdir -p "$output"
  export PROFILE_COMMIT=$PROFILE_BASE
  if [ "$variant" = pr ]; then export PROFILE_COMMIT=$PROFILE_HEAD; fi
  if [ "$trial" = 1 ] && [ "$mode" = optim ]; then steps=17; profile_step=17; fi
  export MB_STEPS=40 MB_TB=1
  export PYTHONPATH="$PROFILE_ROOT/$variant:$PROFILE_ROOT/harness"
  cd "$PROFILE_ROOT/$variant"
  echo "START $workload $variant trial$trial $mode"
  timeout --signal=TERM --kill-after=20s 480s \
    "$PROFILE_ROOT/venv/bin/torchrun" --nproc_per_node=8 \
    --rdzv_backend=c10d --rdzv_endpoint=localhost:0 \
    "$PROFILE_ROOT/harness/muon_bench.py" --module workloads --config "$workload" \
    --mb.mode="$mode" --mb.out="$output" --mb.steps="$steps" --mb.warmup=4 \
    --mb.profile_step="$profile_step" --mb.profile_ranks=0,1,2,3,4,5,6,7 \
    > "$output/run.log" 2>&1
  echo "DONE $workload $variant trial$trial $mode"
}

case ${1:-primary} in
  primary)
    for trial in 1 2 3; do
      if [ "$trial" = 2 ]; then order='pr base'; else order='base pr'; fi
      for variant in $order; do run_one "$variant" k25_slice "$trial" optim; done
    done
    ;;
  numerics)
    for variant in base pr; do run_one "$variant" debug_text 1 train; done
    ;;
  secondary)
    for trial in 1 2 3; do
      if [ "$trial" = 2 ]; then order='pr base'; else order='base pr'; fi
      for variant in $order; do run_one "$variant" moonlight_slice "$trial" optim; done
    done
    ;;
  *) exit 2 ;;
esac
